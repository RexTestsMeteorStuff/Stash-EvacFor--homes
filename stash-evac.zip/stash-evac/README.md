# Stash Evac (Meteor addon, MC 26.2)

## Setup
1. Clone https://github.com/MeteorDevelopment/meteor-addon-template and keep its Gradle wrapper/build files.
2. Replace its `src/main` with this folder's `src/main` (delete the template's example package).
3. In the template's version config set: Minecraft 26.2, Meteor `26.2-SNAPSHOT`, Fabric Loader `0.19.3`+, Java 25.
4. `./gradlew build` -> jar in `build/libs/`. Drop it in `mods/` next to Meteor Client 26.2.

## Use
Enable `stash-evac` (category StashEvac), set `target` to your alt, adjust range/cooldown.
Default sends `/tpa <target>` when a non-friend comes within 64 blocks.

## Chest Evac module (`chest-evac`)
Cycle: **evac** nearest chests -> **chat message** (sent once) -> wait -> **deposit** into nearest chest -> repeat.
- Evac destination: Inventory / EChest / Both (Both = fill inventory, overflow to ender chest).
- Deposit source: Inventory / EChest / Both.
- Ender chest must be within reach (and behind you if `echest-behind-only` is on).
- Bind, Active toggle and Chat Feedback rows are Meteor's standard module window.
